#try except, else block



try:
    i=1/0
except:
    print("Error")
else:
    print("OK")