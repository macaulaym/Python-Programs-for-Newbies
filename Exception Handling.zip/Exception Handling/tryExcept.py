#try block

try:
    a=13
    print(a)
except:
    print ("Exception occurred")

